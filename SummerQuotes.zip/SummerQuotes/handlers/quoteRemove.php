<?php
session_start();

//if(!empty($_POST['quoteID'])){
//    $user->removeQuote($_SESSION['user_session']);
//}

