<?php
session_start();

require_once 'dbconfig.php';

if($_POST)
{
    $quote_string = $_POST['quoteString'];
    $quote_Author = $_POST['quoteAuthor'];

    try{

        $stmt = $db_con->prepare("INSERT INTO tbl_quote(quoteString,quoteAuthor) VALUES(:quote_string,:quote_Author)");
        $stmt->bindParam(":quote_string", $quote_string);
        $stmt->bindParam(":quote_Author",$quote_Author);

        if($stmt->execute())
        {
            echo "Successfully Added";
        }
        else{
            echo "Query Problem";
        }
    }
    catch(PDOException $e){
        echo $e->getMessage();
    }
}